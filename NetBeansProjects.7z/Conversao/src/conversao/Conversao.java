/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversao;

import java.util.Scanner;

/**
 *
 * @author 1302120115
 */
public class Conversao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
  
        Scanner sc = new Scanner(System.in);
        System.out.println("Informe o peso em quilos que deseja converter para libras: ");
        Float Quilo = sc.nextFloat();
        double Libra = Quilo * 2.2;
        System.out.println("A quantidade de quilos que você escolheu convertido para libras é " + Libra);
    }
    
}
